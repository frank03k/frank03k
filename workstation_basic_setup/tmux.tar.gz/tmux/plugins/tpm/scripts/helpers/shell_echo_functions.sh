echo_ok() {
	echo "$*"
}

echo_err() {
	fail_helper "$*"
}
