describe 'suggestion fetching' do
  it 'is performed synchronously'

  context 'when ZSH_AUTOSUGGEST_USE_ASYNC is set' do
    it 'is performed asynchronously'
  end
end
