autoload bashcompinit
bashcompinit

0=${(%):-%N}
source ${0:A:h}/timewarrior.zsh
source ${0:A:h}/_timew
